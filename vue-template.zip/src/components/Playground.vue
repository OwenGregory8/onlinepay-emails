<template>
  <v-app-bar>
    <v-icon>mdi-vuetify</v-icon>
    <v-toolbar-title>Welcome to the Playground</v-toolbar-title>
  </v-app-bar>
</template>

<script>
export default {
  name: "playground",
  data: () => ({
    //
  })
};
</script>
